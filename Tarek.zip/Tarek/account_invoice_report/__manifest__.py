{
    'name': "account_invoice_report",
    'author': "Beshoy Wageh",
    'website': "https://www.linkedin.com/in/beshoy-wageh-701ba7116/",
    'depends': ['base', 'l10n_gcc_invoice','l10n_sa_invoice'],
    'data': [
        'views/templates.xml',
    ],
}
