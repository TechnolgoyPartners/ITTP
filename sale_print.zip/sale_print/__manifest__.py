{
    'name': "Sale Print",
    'author': "Beshoy Wageh",
    'website': "https://www.linkedin.com/in/beshoy-wageh-701ba7116/",
    'depends': ['base', 'sale'],
    'data': [
        'views/header_custom.xml',
        'views/templates.xml',
    ],
}
